package cn.it.utils;

import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;


//拦截器
public class LoginInterceptor implements HandlerInterceptor {

    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler, HttpSession session) throws ServletException, IOException {

        Object object=request.getSession().getAttribute("userInfo");
        if(object!=null||object==""){
            return  true;
        }else {
        request.getRequestDispatcher("Login.jsp").forward(request,response);
        return false;
        }
    }
}
