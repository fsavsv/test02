package cn.it.controller;


import cn.it.domain.UserInfo;
import cn.it.service.LoginService;

import cn.it.utils.Md5Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/login")
public class LoginController {


    @Autowired
    public LoginService loginService;
    //登录验证
    /*@RequestMapping("/findLogin.do")
    public  String findLogin(HttpSession session,@RequestParam("username") String username, @RequestParam("password") String password,@RequestParam("yzm") String yzm, Model model){

        //System.out.println(username);
        //System.out.println(password);
        String string2Md516= Md5Utils.string2Md5_16(password);
        UserInfo userInfo =loginService.findLogin(username,string2Md516);
        //System.out.println(userInfo);
        String verifycode=(String)session.getAttribute("verifycode");
        if(userInfo!=null){
            if(yzm.trim().length()==0||yzm==""){
                model.addAttribute("msg","请输入验证码！！！");
                return "forward:/Login.jsp";
            }else {
                if(!yzm.equalsIgnoreCase(verifycode)){
                    model.addAttribute("msg","请输入正确的验证！！！");
                    return "forward:/Login.jsp";
                }else {
                    //登录成功！！
                    session.setAttribute("userInfo",userInfo);
                    session.setAttribute("username",userInfo.getUsername());
                    return "main";
                      }
                      }
        }else{
            //登录失败！！
            model.addAttribute("msg","账户或密码登录错误！！！");
            return "forward:/Login.jsp";
        }

    }*/


    @RequestMapping("/findLogin.do")
    public  String findLogin(@RequestParam("username") String username, @RequestParam("password") String password, Model model){
        System.out.println(username);
        System.out.println(password);
        String string2Md516= Md5Utils.string2Md5_16(password);
        UserInfo userInfo =loginService.findLogin(username,string2Md516);
        System.out.println(userInfo);
       if(userInfo!=null){
            return "index";
       }else{
           return "forward:all-admin-login.html";
        }

    }

   @RequestMapping("/loginOut.do")
    public String loginOut(HttpSession session){
        session.invalidate();
        return "forward:/Login.jsp";
   }
}
