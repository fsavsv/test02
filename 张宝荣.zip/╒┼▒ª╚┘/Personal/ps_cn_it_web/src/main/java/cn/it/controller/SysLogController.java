package cn.it.controller;


import cn.it.domain.SysLog;
import cn.it.service.ISysLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/sysLog")
public class SysLogController {

    @Autowired
    private ISysLogService sysLogService;


    @RequestMapping("/findAllLog.do")
    public ModelAndView findAllLog(){
        ModelAndView mv=new ModelAndView();
        List<SysLog> sysLogList=sysLogService.findAllLog();
        mv.addObject("sysLogList",sysLogList);
        mv.setViewName("sysLogList");
        return  mv;
    }


    // 路径  /sysLog/deleteAllSyslog.do
    //根据id来批量删除
    @RequestMapping("/deleteAllSyslog.do")
    public  String  deleteAllSyslog(@RequestParam(value = "ids",required = true) Integer[] ids){

        sysLogService.deleteAllSyslog(ids);
        return "redirect:findAllLog.do";
    }

}
