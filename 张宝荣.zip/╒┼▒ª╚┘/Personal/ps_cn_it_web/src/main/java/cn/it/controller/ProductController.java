package cn.it.controller;





import cn.it.domain.Product;
import cn.it.service.IProductService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/product")
public class ProductController {

    @Autowired
    private IProductService productService;
    @RequestMapping("/findAllProduct.do")
    public ModelAndView findAll(){

        ModelAndView modelAndView=new ModelAndView();
        List<Product> productList =productService.findAllProduct();

        modelAndView.addObject("productList",productList);
        modelAndView.setViewName("list");
        return modelAndView;
    }

    //跳转到添加页面

    @RequestMapping("/saveUrl.do")
    public String saveUrl(){

        return "Addpro";
    }


    //添加产品
    @RequestMapping("/saveProduct.do")
    public String  saveProduct( Product product){
        System.out.println(product);
        productService.saveProduct(product);

//添加完成重新运行查询方法
        return "redirect:findAllProduct.do";
    }

    //修改
    @RequestMapping("/edit.do")
    public ModelAndView Edit(Integer id){
        ModelAndView modelAndView=new ModelAndView();
        Product product=productService.findProductById(id);
        modelAndView.addObject("product",product);
        System.out.println(product);
        modelAndView.setViewName("Editpro");
        return modelAndView;
    }

    @RequestMapping("/updateProduct.do")
    public String updateProduct(Product product){
        System.out.println(product);
        productService.updateProduct(product);
        return "redirect:findAllProduct.do";
    }
//修改结束


    //根据id来删除
    @RequestMapping("/delete.do")
    public  String  deleteByID(@RequestParam(value = "pid",required = true) Integer id){

        productService.deleteByID(id);
        System.out.println("删除成功！");

        return "redirect:findAllProduct.do";
    }

    //模糊查询
    @RequestMapping("/findby.do")
    public ModelAndView FindBy(String productName){
        ModelAndView modelAndView=new ModelAndView();
        String productName1="%"+productName+"%";
        List<Product> productList=productService.FindBy(productName1);
      /*  System.out.println(productName1);
        System.out.println(productList);*/
/*        for (Product product:productList) {
            System.out.println(product);
        }*/
        modelAndView.addObject("productList",productList);
        modelAndView.setViewName("productList");
        return modelAndView;
    }

    //模糊查询结束

//分页查询
    @RequestMapping("/findAllProductPages.do")
    public ModelAndView findAllProductPages(@RequestParam(name ="page",required = true,defaultValue = "1")Integer page,@RequestParam(name = "size",required = true,defaultValue = "6") Integer size){
        ModelAndView mv=new ModelAndView();
        //获取分页数据
        List<Product> productList  =productService.findAllProductPages(page,size);

        PageInfo pageInfo=new PageInfo(productList);
        mv.addObject("pageInfo",pageInfo);

        mv.setViewName("productListPages");
        return mv;
    }


    //模糊查询
    @RequestMapping("/findAllProductPagesBy.do")
    public ModelAndView findAllProductPagesBy(String productName,@RequestParam(name ="page",required = true,defaultValue = "1")Integer page,@RequestParam(name = "size",required = true,defaultValue = "6") Integer size){
        ModelAndView mv=new ModelAndView();
        String productName1="%"+productName+"%";
        //获取分页数据
        List<Product> productList  =productService.findAllProductPagesBy(productName1,page,size);

        PageInfo pageInfo=new PageInfo(productList);
        mv.addObject("pageInfo",pageInfo);

        mv.setViewName("productListPages");
        return mv;
    }

    //模糊查询结束
//分页查询结束

}
