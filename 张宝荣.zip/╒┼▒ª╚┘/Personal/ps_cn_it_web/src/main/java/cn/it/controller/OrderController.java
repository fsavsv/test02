package cn.it.controller;


import cn.it.domain.Orders;
import cn.it.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/order")
public class OrderController {


    @Autowired
    private OrderService orderService;



    @RequestMapping("/findOrders.do")
    public ModelAndView findOrders(){
        ModelAndView mv=new ModelAndView();
        List<Orders> orderList=orderService.findOrders();
        System.out.println(orderList);
        mv.addObject("orderList",orderList);
        mv.setViewName("orderList");
        return mv;
    }


    @RequestMapping("/findOrdersById.do")
    public  ModelAndView findOrdersById(Integer id){
        ModelAndView mv=new ModelAndView();
        Orders orders=orderService.findOrdersById(id);
        System.out.println(orders);
        mv.addObject("orders",orders);
        mv.setViewName("orderEdit");
        return mv;
    }
}
