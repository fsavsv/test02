package cn.it.controller;


import cn.it.domain.Product;
import cn.it.domain.Role;
import cn.it.domain.UserInfo;
import cn.it.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    //findAll.do

    @RequestMapping("/findAllUser.do")
    public ModelAndView findAllUser(){
        ModelAndView mv=new ModelAndView();
        //测试500错误int a=1/0;
        List<UserInfo> userInfoList=userService.findAllUser();
        mv.addObject("userInfoList",userInfoList);
        //测试404错误mv.setViewName("userList123");
        mv.setViewName("userList");
        return mv;
    }

    //添加用户
    //跳转到添加页面

    @RequestMapping("/saveUrl.do")
    public String saveUrl(){
        return "AddUser";
    }


    //添加产品
    @RequestMapping("/saveUser.do")
    public String  saveProduct( UserInfo userInfo){
        System.out.println(userInfo);
        userService.saveUser(userInfo);

//添加完成重新运行查询方法
        return "redirect:findAllUser.do";
    }
    //添加用户

    //删除用户
    //deleteUser.do
    //根据id来删除
    @RequestMapping("/deleteUser.do")
    public  String  deleteByID(@RequestParam(value = "pid",required = true) Integer id){

        userService.deleteByID(id);
        System.out.println("删除成功！");

        return "redirect:findAllUser.do";
    }
    //删除用户

    //修改
    @RequestMapping("/editUser.do")
    public ModelAndView Edit(Integer id){
        ModelAndView modelAndView=new ModelAndView();
        UserInfo userInfo=userService.findUserById(id);
        modelAndView.addObject("userInfo",userInfo);
        modelAndView.setViewName("EditUser");
        return modelAndView;
    }

    @RequestMapping("/updateUser.do")
    public String updateProduct(UserInfo userInfo){
        System.out.println(userInfo);
        userService.updateUser(userInfo);
        return "redirect:findAllUser.do";
    }
//修改结束

    //用户角色添加
    //findUserToRole.do
    @RequestMapping("/findUserToRole.do")
    public ModelAndView findUserToRole(Integer id){
        System.out.println(id);
        ModelAndView mv=new ModelAndView();
        UserInfo userInfo=userService.findUserToRole(id);
        System.out.println(userInfo);
        mv.addObject("userInfo",userInfo);
        mv.setViewName("showRole");
        return  mv;
    }

    //saveUserToRole.do
    @RequestMapping("/saveUserToRole.do")
    public String saveUserToRole(@RequestParam(value = "userId",required = true)Integer userId,@RequestParam(value = "ids",required = true)Integer[] rolesId){
        userService.saveUserToRole(userId,rolesId);
        return "redirect:findAllUser.do";
    }

    //用户角色添加


    //查看用户的角色和资源权限
    //根据用户ID查询用户有的角色findUserToRoleById.do
    @RequestMapping("/findUserToRoleById.do")
    public ModelAndView findUserToRoleById(Integer id){
        ModelAndView mv=new ModelAndView();
        UserInfo userInfo=userService.findUserToRoleById(id);
        mv.addObject("userInfo",userInfo);
        mv.setViewName("user_role_permission");
        return mv;
    }


}
