package cn.it.service;


import cn.it.domain.Role;
import cn.it.domain.UserInfo;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;

public interface UserService extends UserDetailsService{

    List<UserInfo> findAllUser();

    void saveUser(UserInfo userInfo);

    void deleteByID(Integer id);

    UserInfo findUserById(Integer  id);

    void updateUser(UserInfo userInfo);

    UserInfo findUserToRole(Integer id);


    void saveUserToRole(Integer userId, Integer[] rolesId);

    UserInfo findUserToRoleById(Integer id);
}
