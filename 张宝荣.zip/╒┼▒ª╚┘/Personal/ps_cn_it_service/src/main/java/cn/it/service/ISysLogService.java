package cn.it.service;

import cn.it.domain.SysLog;

import java.util.List;

public interface ISysLogService {
    void save(SysLog sysLog);

    List<SysLog> findAllLog();

    void deleteAllSyslog(Integer[] ids);
}
