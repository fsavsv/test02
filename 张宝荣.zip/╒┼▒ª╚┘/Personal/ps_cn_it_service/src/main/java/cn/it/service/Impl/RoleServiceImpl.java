package cn.it.service.Impl;

import cn.it.dao.RoleDao;
import cn.it.domain.Role;
import cn.it.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
@Transactional
public class RoleServiceImpl implements RoleService{

    @Autowired
    private RoleDao roleDao;

    public List<Role> findAllRole() {
        return roleDao.findAllRole();
    }

    //����id��ѯ��ɫӵ�е���ԴȨ��
    public Role findRoleByPermission(Integer id) {
        return roleDao.findRoleByPermission(id);
    }
}
