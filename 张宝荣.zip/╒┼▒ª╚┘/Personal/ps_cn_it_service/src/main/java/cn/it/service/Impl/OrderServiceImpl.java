package cn.it.service.Impl;

import cn.it.dao.OrderDao;
import cn.it.domain.Orders;
import cn.it.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
@Transactional
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderDao orderDao;

    public List<Orders> findOrders() {
        return orderDao.findOrders();
    }

    public Orders findOrdersById(Integer id) {
        return orderDao.findOrdersById(id);
    }
}
