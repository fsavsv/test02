package cn.it.service;

import cn.it.domain.Role;

import java.util.List;

public interface RoleService {
    List<Role> findAllRole();

    Role findRoleByPermission(Integer id);
}
