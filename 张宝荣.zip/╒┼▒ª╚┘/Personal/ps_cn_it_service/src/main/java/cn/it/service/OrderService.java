package cn.it.service;

import cn.it.domain.Orders;

import java.util.List;

public interface OrderService {
    List<Orders> findOrders();

    Orders findOrdersById(Integer id);
}
