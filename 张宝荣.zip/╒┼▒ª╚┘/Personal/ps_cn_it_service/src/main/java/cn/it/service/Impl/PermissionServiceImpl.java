package cn.it.service.Impl;


import cn.it.dao.PermissionDao;
import cn.it.domain.Permission;
import cn.it.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class PermissionServiceImpl implements PermissionService {

    @Autowired
    private PermissionDao permissionDao;

    public List<Permission> findAll() {
        return permissionDao.findAll();
    }

    public Permission findPermissionByRole(Integer id) {
        return permissionDao.findPermissionByRole(id);
    }

    public void savePermissionToRole(Integer permissionId, Integer[] rolesId) {
        for(Integer roleId:rolesId){
            permissionDao.savePermissionToRole(permissionId,roleId);
        }
    }
}
