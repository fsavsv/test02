package cn.it.service.Impl;



import cn.it.dao.LoginDao;
import cn.it.domain.UserInfo;
import cn.it.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional //加上声明式事务
public class LoginServiceImpl implements LoginService {

    @Autowired
    private LoginDao loginDao;


    public UserInfo findLogin(String username, String password) {
        UserInfo userInfo=  loginDao.findLogin( username,password);
        return userInfo;
    }
}
