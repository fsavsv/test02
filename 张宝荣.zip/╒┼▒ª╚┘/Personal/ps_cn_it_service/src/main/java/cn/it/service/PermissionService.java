package cn.it.service;

import cn.it.domain.Permission;

import java.util.List;

public interface PermissionService {

    List<Permission> findAll();

    Permission findPermissionByRole(Integer id);

    void savePermissionToRole(Integer permissionId, Integer[] rolesId);
}
