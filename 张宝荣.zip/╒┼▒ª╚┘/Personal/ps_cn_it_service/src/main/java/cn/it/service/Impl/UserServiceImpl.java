package cn.it.service.Impl;

import cn.it.dao.UserDao;
import cn.it.domain.Role;
import cn.it.domain.UserInfo;
import cn.it.service.UserService;
import cn.it.utils.BCryptPasswordEncoderUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;


@Service("userService")
@Transactional
public class UserServiceImpl implements UserService {

    //ע��userDao
    @Autowired
    private UserDao userDao;

    //��¼��֤
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserInfo userInfo=userDao.findByUserName(username);

        /*δ���ܵĴ���*/
        //User users=new User(userInfo.getUsername(),"{noop}"+userInfo.getPassword(),getAuthority(userInfo.getRoles()));

        /*���ܺ�Ĵ���*/
        User users=new User(userInfo.getUsername(),userInfo.getPassword(),getAuthority(userInfo.getRoles()));
        return users;
    }

    //���þ��Ƿ���һ��List���ϣ�������װ����ǽ�ɫ����
    public List<SimpleGrantedAuthority> getAuthority(List<Role> roles) {

        List<SimpleGrantedAuthority> list = new ArrayList();
        for (Role role : roles) {
            list.add(new SimpleGrantedAuthority("ROLE_" + role.getRoleName()));
        }
        return list;
    }

    //��ѯ����
    public List<UserInfo> findAllUser() {
        return userDao.findAllUser();
    }


    //�����û�
    public void saveUser(UserInfo userInfo) {

        //���������
        userInfo.setPassword(BCryptPasswordEncoderUtils.encodePassword(userInfo.getPassword()));
        userDao.saveUser(userInfo);
    }

    public void deleteByID(Integer id) {
        userDao.deleteByUsers_role(id);
        userDao.deleteByID(id);
    }

    public UserInfo findUserById(Integer id) {
        return userDao.findUserById(id);
    }

    public void updateUser(UserInfo userInfo) {
        userInfo.setPassword(BCryptPasswordEncoderUtils.encodePassword(userInfo.getPassword()));
        userDao.updateUser(userInfo);
    }

    public UserInfo findUserToRole(Integer id) {
        return userDao.findUserToRole(id);
    }

    public void saveUserToRole(Integer userId, Integer[] rolesId) {
        for(Integer roleId:rolesId){
            userDao.saveUserToRole(userId,roleId);
        }
    }


    //�����û�ID��ѯ�û��еĽ�ɫ
    public UserInfo findUserToRoleById(Integer id) {
        return userDao.findUserToRoleById(id);
    }


}
