package cn.it.service.Impl;

import cn.it.dao.ProductDao;
import cn.it.domain.Product;
import cn.it.service.IProductService;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional //加上声明式事务
public class ProductServiceImpl implements IProductService {

    //调用dao
    @Autowired
    private ProductDao productDao;
    public List<Product> findAllProduct() {
        return productDao.findAllProduct();
    }


    //保存
    public void saveProduct(Product product) {
        productDao.saveProduct(product);
        System.out.println("service:"+product);
    }


    public void deleteByID(Integer id) {
        productDao.deleteByID(id);
    }

    public Product findProductById(Integer id) {
        return productDao.findProductById(id);

    }

    public void updateProduct(Product product) {
        productDao.updateProduct(product);
    }

    public List<Product> FindBy(String productName) {
        return productDao.FindBy(productName);
    }

    public List<Product> findAllProductPages(Integer page, Integer size) {
        //参数pageNum 是页码值   参数pageSize 代表是每页显示条数
        PageHelper.startPage(page,size);
        return  productDao.findAllProductPages();
    }

    public List<Product> findAllProductPagesBy(String productName1, Integer page, Integer size) {
        //参数pageNum 是页码值   参数pageSize 代表是每页显示条数
        PageHelper.startPage(page,size);
        return  productDao.findAllProductPagesBy(productName1);
    }
}
