package cn.it.service.Impl;

import cn.it.dao.ISysLogDao;
import cn.it.domain.SysLog;
import cn.it.service.ISysLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ISysLogServiceImpl implements ISysLogService {


    @Autowired
    private ISysLogDao sysLogDao;
    public void save(SysLog sysLog) {
        sysLogDao.save(sysLog);
    }

    public List<SysLog> findAllLog() {
        return sysLogDao.findAllLog();
    }

    public void deleteAllSyslog(Integer [] ids) {
        for (Integer id:ids) {
            sysLogDao.deleteAllSyslog(id);
        }
    }
}
