package cn.it.service;

import cn.it.domain.UserInfo;

public interface LoginService {
    UserInfo findLogin(String username, String password);
}
