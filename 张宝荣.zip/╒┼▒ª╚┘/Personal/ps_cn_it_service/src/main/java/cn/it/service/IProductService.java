package cn.it.service;


import cn.it.domain.Product;

import java.util.List;

public interface IProductService {

    List<Product> findAllProduct();

    //保存产品
     void  saveProduct(Product product);


    void  deleteByID(Integer id);

    Product findProductById(Integer id);

    void updateProduct(Product product);

    List<Product> FindBy(String productName);

    List<Product> findAllProductPages(Integer page, Integer size);

    List<Product> findAllProductPagesBy(String productName1, Integer page, Integer size);
}
