package cn.it.dao;


import cn.it.domain.Permission;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PermissionDao {


    @Select("select * from permission where id in( select permissionId from role_permission where roleId=#{role_id})")
    List<Permission> findRoleByPermission(Integer role_id);

    @Select("select * from permission")
    List<Permission> findAll();


    @Select("select *  from permission where id=#{id}")
    @Results({
            @Result(id = true, property = "id",column = "id"),
            @Result(property = "permissionName",column = "permissionName"),
            @Result(property = "url",column = "url"),
            @Result(property = "roles",column = "id",javaType = java.util.List.class,many = @Many(select = "cn.it.dao.RoleDao.findPermisssionByRole"))
    })
    Permission findPermissionByRole(Integer id);


    /*@Insert("insert into users_role(userId,roleId)values(#{userId},#{roleId})")
    void saveUserToRole(@Param("userId")int userId, @Param("roleId")int roleId);*/
    @Insert("insert into role_permission(permissionId,roleId)values(#{permissionId},#{roleId})")
    void savePermissionToRole(@Param("permissionId")Integer permissionId, @Param("roleId")Integer roleId);
}
