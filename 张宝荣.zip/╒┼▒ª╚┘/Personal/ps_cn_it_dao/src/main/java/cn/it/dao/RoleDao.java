package cn.it.dao;


import cn.it.domain.Role;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RoleDao {

    @Select("select *  from role where id in(select roleId from users_role where userId=#{user_id} )")
   @Results({
           @Result(id = true,property = "id",column = "id"),
           @Result(property = "roleName",column = "roleName"),
           @Result(property = "roleDesc",column = "roleDesc"),
           @Result(property = "permissions",column = "id",javaType = java.util.List.class,many = @Many(select = "cn.it.dao.PermissionDao.findRoleByPermission"))
   })
    List<Role> findByID(Integer user_id);

    @Select("SELECT * FROM role WHERE id not in(SELECT roleId from users_role where userId=#{user_id})")
    List<Role> findByRole(Integer user_id);

    @Select("select * from role")
    List<Role> findAllRole();


    @Select("select *  from role where id=#{id}")
    @Results({
            @Result(id = true,property = "id",column = "id"),
            @Result(property = "roleName",column = "roleName"),
            @Result(property = "roleDesc",column = "roleDesc"),
            @Result(property = "permissions",column = "id",javaType = java.util.List.class,many = @Many(select = "cn.it.dao.PermissionDao.findRoleByPermission"))
    })
    Role findRoleByPermission(int id);

    @Select("SELECT * FROM role WHERE id not in(SELECT roleId from role_permission where permissionId=#{permissionId})")
    List<Role> findPermisssionByRole(Integer permissionId);
}
