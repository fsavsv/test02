package cn.it.dao;


import cn.it.domain.Product;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository  //持久层
public interface ProductDao {

    @Select("select *  from product")
    List<Product> findAllProduct();



    //保存产品
    @Insert("insert into product (productNum,productName,cityName,departureTime,productPrice,productDesc,productStatus) values(#{productNum},#{productName},#{cityName},#{departureTime},#{productPrice},#{productDesc},#{productStatus})")
    void  saveProduct(Product product);





    @Delete("delete from product where id=#{id}")
    void  deleteByID(Integer id);

    @Select("select *  from product where id=#{id}")
    Product findProductById(int id);

    //关联一个id查询
    @Select("select *  from product where id=#{id}")
    Product  findByID(Integer id);

   // @Update("update product set productNum=#{productNum},productName=#{productName},cityName=#{cityName},departureTime=#{departureTimeStr},productPrice={productPrice},productDesc=#{productDesc},productStatus=#{productStatus}) where id=#{id}")
   @Update("update product set productNum=#{productNum},productName=#{productName},cityName=#{cityName},departureTime=#{departureTime},productPrice=#{productPrice},productDesc=#{productDesc},productStatus=#{productStatus} where id=#{id}")
    void updateProduct(Product product);


   @Select("select *  from product where 1=1 and productName like #{productName}")
    List<Product> FindBy(String productName);


   //分页查询
    @Select("select * from product")
    List<Product> findAllProductPages();


    @Select("select *  from product where productName like #{name}")
    List<Product> findAllProductPagesBy(String name);
}
