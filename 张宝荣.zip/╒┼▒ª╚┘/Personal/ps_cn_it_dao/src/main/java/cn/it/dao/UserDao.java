package cn.it.dao;


import cn.it.domain.Product;
import cn.it.domain.Role;
import cn.it.domain.UserInfo;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserDao {

    @Select("select *  from users where username=#{username}")
    @Results({
            @Result(id = true, property = "id",column = "id"),
            @Result(property = "username",column = "username"),
            @Result(property = "password",column = "password"),
            @Result(property = "email",column = "email"),
            @Result(property = "phoneNum",column = "phoneNum"),
            @Result(property = "status",column = "status"),
            @Result(property = "roles",column = "id",javaType = java.util.List.class,many = @Many(select = "cn.it.dao.RoleDao.findByID"))
    })
    UserInfo findByUserName(String username);


    @Select("select * from users")
    List<UserInfo> findAllUser();

    //�����Ʒ
    @Insert("insert into users (email,username,password,phoneNum,status) values(#{email},#{username},#{password},#{phoneNum},#{status})")
    void saveUser(UserInfo userInfo);

    @Delete("delete from users_role where userId=#{id}")
    void deleteByUsers_role(Integer id);
    @Delete("delete from users where id=#{id}")
    void deleteByID(Integer id);

    @Select("select *  from users where id=#{id}")
    UserInfo findUserById(int id);

    @Update("update users set email=#{email},username=#{username},password=#{password},phoneNum=#{phoneNum},status=#{status} where id=#{id}")
    void updateUser(UserInfo userInfo);


    @Select("select *  from users where id=#{id}")
    @Results({
            @Result(id = true, property = "id",column = "id"),
            @Result(property = "username",column = "username"),
            @Result(property = "password",column = "password"),
            @Result(property = "email",column = "email"),
            @Result(property = "phoneNum",column = "phoneNum"),
            @Result(property = "status",column = "status"),
            @Result(property = "roles",column = "id",javaType = java.util.List.class,many = @Many(select = "cn.it.dao.RoleDao.findByRole"))
    })
    UserInfo findUserToRole(Integer id);

    // ��ָ�����û����ӽ�ɫ
    @Insert("insert into users_role(userId,roleId)values(#{userId},#{roleId})")
    void saveUserToRole(@Param("userId")int userId, @Param("roleId")int roleId);



    //�����û�ID��ѯ�û��еĽ�ɫ
    @Select("select *  from users where id=#{id}")
    @Results({
            @Result(id = true, property = "id",column = "id"),
            @Result(property = "username",column = "username"),
            @Result(property = "password",column = "password"),
            @Result(property = "email",column = "email"),
            @Result(property = "phoneNum",column = "phoneNum"),
            @Result(property = "status",column = "status"),
            @Result(property = "roles",column = "id",javaType = java.util.List.class,many = @Many(select = "cn.it.dao.RoleDao.findByID"))
    })
    UserInfo findUserToRoleById(Integer id);


}
