package cn.it.dao;


import cn.it.domain.UserInfo;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface LoginDao {

    @Select("select *  from users where username=#{username} and password=#{password}")
    UserInfo findLogin(@Param("username") String username, @Param("password") String password);
}
